from __future__ import annotations
import os
import configparser
from typing import List


class Setting:

    ROOTDIR = os.path.abspath('')
    FILE_EXT: str = 'csv'
    LOCAL_FIGURECONFIG_FILENAME: str = 'Plot Config.csv'
    selected_figureconfig_filename: str = LOCAL_FIGURECONFIG_FILENAME  # Biến động lưu file cấu hình đang chọn

    INPUT_DIR = os.path.abspath("Input")
    OUTPUT_DIR = os.path.abspath("Output")

    # Local preference which load from local and show on UI
    OPTS_LOCAL_FILENAME = 'preference.ini'
    # Rotation of Dataset label on Plot Figure. # 0: no rotation
    OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION: int = 0
    OPTS_PLOTCONFIG_SHOW_MEDIAN: bool = False
    OPTS_MEDIAN_FONT_SIZE: int = 0
    OPTS_DATACONFIG_IMPORT_SKIP_ROW = [1, 2]  # List of integer

    # following Minitab software Boxplot style
    PICTURE_WIDTH_HEIGHT_RATIO: float = 1.48
    PICTURE_MAX_WIDTH: float = 10.5
    PICTURE_MAX_HEIGHT: float = 4.65
    PLOTCONFIG_DATASET_NAME_LIST: List[str] = []

    # Added as per instructions
    OPTS_PLOTCONFIG_SHOW_CPK: bool = False  # Thêm dòng này
    OPTS_PLOTCONFIG_SHOW_N: bool = False    # Thêm dòng này
    OPTS_PLOTCONFIG_SHOW_VIOLIN = True  # Giá trị mặc định
    OPTS_PLOTCONFIG_SHOW_INDIVIDUAL = True  # Thêm setting mới cho individual plot
    OPTS_PLOTCONFIG_USE_GRADIENT = True  # Mặc định bật gradient colors

    # Thêm setting mới cho Plot Title font size
    OPTS_PLOT_TITLE_FONT_SIZE: int = 6  # Giá trị mặc định là 6

    # Thêm setting mới cho Dataset Label font size
    OPTS_DATASET_LABEL_FONT_SIZE: int = 5  # Giá trị mặc định

    # Thêm setting mới cho vị trí text
    OPTS_PLOTCONFIG_TEXT_POSITION: str = "Default"  # Mặc định là Default

    # Data count method
    OPTS_DATA_COUNT_METHOD = "Short_SN"  # "Data_value" or "Short_SN"

    # Control Spec Line settings
    OPTS_CONTROL_SPEC_REF_FILE: str = "None"  # Reference file for control spec calculation
    OPTS_CONTROL_SPEC_VALUE: str = "±1.5σ"  # Control spec value (sigma level)
    OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS: bool = False  # Highlight control spec violations
    OPTS_SHOW_CONTROL_SPEC_LINES: bool = False  # Show control spec lines
    OPTS_ONLY_SHOW_CONTROL_SPEC_VIOLATIONS: bool = False  # Only show violations

    @staticmethod
    def get_config_csv_files() -> list:
        # Lấy tất cả file .csv ở thư mục gốc (trừ Input/Output)
        files = []
        for f in os.listdir(Setting.ROOTDIR):
            if f.lower().endswith('.csv') and os.path.isfile(f):
                files.append(f)
        return files

    def __init__(self):
        self.cfgparser = configparser.ConfigParser()
        self.cfgparser.optionxform = str  # preserve case when read/write from/to INI file
        
        # Kiểm tra xem section 'OPTION' đã tồn tại chưa
        if not self.cfgparser.has_section('OPTION'):
            self.cfgparser.add_section('OPTION')
        
        # Load settings từ file
        self.loadSetting()

    def loadSetting(self) -> None:
        # Đọc file preference.ini nếu tồn tại
        if os.path.exists("preference.ini"):
            self.cfgparser.read("preference.ini", encoding='utf-8')
        
        # Initialization
        dataset_labelrotation = 0
        rowskip = ""
        show_median = False
        show_cpk = False
        show_n = False
        show_violin = True
        median_fontsize = 6
        show_individual = True
        use_gradient = True  # Giá trị mặc định cho gradient
        text_position = "Default"  # Giá trị mặc định cho text position

        # PARSING VALUE FROM LOCAL FILE
        try:
            dataset_labelrotation = self.cfgparser["OPTION"]["DATASET_LABEL_ROTATION"]
        except:
            pass
        try:
            rowskip = self.cfgparser["OPTION"]["DATA_IMPORT_SKIP_ROW_NUMBER"]
        except:
            pass
        try:
            show_median = self.cfgparser["OPTION"]["PLOT_SHOW_MEDIAN"]
        except:
            pass
        try:
            show_cpk = self.cfgparser["OPTION"]["PLOT_SHOW_CPK"]
        except:
            pass
        try:
            show_n = self.cfgparser["OPTION"]["PLOT_SHOW_N"]
        except:
            pass
        try:
            show_violin = self.cfgparser["OPTION"]["PLOT_SHOW_VIOLIN"]
        except:
            pass
        try:
            median_fontsize = self.cfgparser["OPTION"]["MEDIAN_FONT_SIZE"]
        except:
            pass
        try:
            show_individual = self.cfgparser["OPTION"]["PLOT_SHOW_INDIVIDUAL"]
        except:
            pass
        try:
            use_gradient = self.cfgparser["OPTION"]["PLOT_USE_GRADIENT"]
        except:
            pass
        try:
            text_position = self.cfgparser["OPTION"]["TEXT_POSITION"]
        except:
            pass

        # Handle data type
        try:
            dataset_labelrotation = int(dataset_labelrotation)
        except:
            dataset_labelrotation = 0

        # Xử lý các giá trị boolean
        if show_median == 'True':
            show_median = True
        else:
            show_median = False

        if show_cpk == 'True':
            show_cpk = True
        else:
            show_cpk = False

        if show_n == 'True':
            show_n = True
        else:
            show_n = False

        if show_violin == 'True':
            show_violin = True
        else:
            show_violin = False

        if show_individual == 'True':
            show_individual = True
        else:
            show_individual = False

        if use_gradient == 'True':
            use_gradient = True
        else:
            use_gradient = False

        if text_position == 'True':
            text_position = "Default"
        else:
            text_position = "Default"

        # Thêm vào phần load setting
        median_fontsize = 5
        try:
            median_fontsize = self.cfgparser["OPTION"]["MEDIAN_FONT_SIZE"]
            median_fontsize = int(median_fontsize)
            if median_fontsize in range(2, 11):
                Setting.OPTS_MEDIAN_FONT_SIZE = median_fontsize
        except:
            Setting.OPTS_MEDIAN_FONT_SIZE = 5


        if type(rowskip) == str:
            rowskip = rowskip.split(' ')
            rowskip = [num for num in rowskip if num.isnumeric()]
            rowskip = list(map(int, rowskip))
            rowskip = [row for row in rowskip if row >= 0]
            if len(rowskip) == 0:
                rowskip = None
        else:
            rowskip = None

        # Thêm vào phần load setting
        plot_title_fontsize = 6
        try:
            plot_title_fontsize = self.cfgparser["OPTION"]["PLOT_TITLE_FONT_SIZE"]
        except:
            pass

        try:
            plot_title_fontsize = int(plot_title_fontsize)
            if not plot_title_fontsize in range(2, 11):  # Thay đổi range thành 2-10
                plot_title_fontsize = 6
        except:
            plot_title_fontsize = 6

        # Thêm vào phần load setting
        dataset_label_fontsize = 5
        try:
            dataset_label_fontsize = self.cfgparser["OPTION"]["DATASET_LABEL_FONT_SIZE"]
            dataset_label_fontsize = int(dataset_label_fontsize)
            if dataset_label_fontsize in range(2, 11):
                Setting.OPTS_DATASET_LABEL_FONT_SIZE = dataset_label_fontsize
        except:
            Setting.OPTS_DATASET_LABEL_FONT_SIZE = 5
            
        # Thêm vào hàm load
        try:
            Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION = dataset_labelrotation
            Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN = show_median
            Setting.OPTS_PLOTCONFIG_SHOW_CPK = show_cpk
            Setting.OPTS_PLOTCONFIG_SHOW_N = show_n
            Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN = show_violin
            Setting.OPTS_MEDIAN_FONT_SIZE = median_fontsize
            Setting.OPTS_DATACONFIG_IMPORT_SKIP_ROW = rowskip
            Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL = show_individual
            Setting.OPTS_PLOTCONFIG_USE_GRADIENT = use_gradient
            Setting.OPTS_PLOT_TITLE_FONT_SIZE = plot_title_fontsize
            Setting.OPTS_PLOTCONFIG_TEXT_POSITION = text_position
        except:
            pass

        # Thêm vào phần load setting
        # Load Control Spec Line settings
        # try:
        #     Setting.OPTS_CONTROL_SPEC_REF_FILE = self.cfgparser["OPTION"].get(
        #         "CONTROL_SPEC_REF_FILE", Setting.OPTS_CONTROL_SPEC_REF_FILE)
        # except:
        #     pass

        try:
            Setting.OPTS_CONTROL_SPEC_VALUE = self.cfgparser["OPTION"].get(
                "CONTROL_SPEC_VALUE", Setting.OPTS_CONTROL_SPEC_VALUE)
        except:
            pass

        try:
            Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS = self.cfgparser["OPTION"].getboolean(
                "HIGHLIGHT_CONTROL_SPEC_VIOLATIONS", Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS)
        except:
            pass

        try:
            Setting.OPTS_SHOW_CONTROL_SPEC_LINES = self.cfgparser["OPTION"].getboolean(
                "SHOW_CONTROL_SPEC_LINES", Setting.OPTS_SHOW_CONTROL_SPEC_LINES)
        except:
            pass

        try:
            Setting.OPTS_ONLY_SHOW_CONTROL_SPEC_VIOLATIONS = self.cfgparser["OPTION"].getboolean(
                "ONLY_SHOW_CONTROL_SPEC_VIOLATIONS", Setting.OPTS_ONLY_SHOW_CONTROL_SPEC_VIOLATIONS)
        except:
            pass

    def saveSetting(
            self,
            plotconfig_datasetLabelRotation: int,
            plotconfig_showMedian: bool,
            plotconfig_showCpk: bool,
            plotconfig_showN: bool,
            plotconfig_showViolin: bool,
            plotconfig_showIndividual: bool,
            plotconfig_useGradient: bool,
            plotconfig_medianFontSize: int,
            plotconfig_titleFontSize: int,
            plotconfig_datasetLabelFontSize: int,
            plotconfig_textPosition: str,
            plotconfig_dataCountMethod: str,
            dataconfig_importSkipRows: List[int],
            control_spec_ref_file: str = "None",
            control_spec_value: str = "±1.5σ",
            highlight_control_spec_violations: bool = False,
            show_control_spec_lines: bool = False,
            only_show_control_spec_violations: bool = False
    ) -> None:
        # argument validation
        if type(plotconfig_datasetLabelRotation) != int:
            plotconfig_datasetLabelRotation = 0
        if not plotconfig_datasetLabelRotation in [0, 45, 90]:
            plotconfig_datasetLabelRotation = 0

        if type(plotconfig_showMedian) != bool:
            plotconfig_showMedian = False
        
        if type(plotconfig_showCpk) != bool:
            plotconfig_showCpk = False
        
        if type(plotconfig_showN) != bool:
            plotconfig_showN = False
        
        if type(plotconfig_showViolin) != bool:
            plotconfig_showViolin = True

        if type(plotconfig_showIndividual) != bool:
            plotconfig_showIndividual = True

        if type(plotconfig_useGradient) != bool:
            plotconfig_useGradient = True

        if type(plotconfig_medianFontSize) != int:
            plotconfig_medianFontSize = 6

        if type(dataconfig_importSkipRows) != list:
            dataconfig_importSkipRows = None
        else:
            dataconfig_importSkipRows = [
                num for num in dataconfig_importSkipRows if type(num) == int]

        # Thêm validation cho title font size
        if type(plotconfig_titleFontSize) != int:
            plotconfig_titleFontSize = 6
        elif plotconfig_titleFontSize not in range(2, 11):
            plotconfig_titleFontSize = 6
        
        # Validation cho dataset label font size
        if type(plotconfig_datasetLabelFontSize) != int:
            plotconfig_datasetLabelFontSize = 5
        elif plotconfig_datasetLabelFontSize not in range(2, 11):
            plotconfig_datasetLabelFontSize = 5

        if not plotconfig_textPosition in ["Default", "Auto", "Vertical"]:
            plotconfig_textPosition = "Default"

        # Control Spec Line validation
        if type(control_spec_ref_file) != str:
            control_spec_ref_file = "None"
        
        if type(control_spec_value) != str:
            control_spec_value = "±1.5σ"
        elif control_spec_value not in ["±1.5σ", "±2.5σ", "±2σ", "±2.5σ", "±3σ", "±3.5σ", "±4σ"]:
            control_spec_value = "±1.5σ"    
        
        if type(highlight_control_spec_violations) != bool:
            highlight_control_spec_violations = False
        
        if type(show_control_spec_lines) != bool:
            show_control_spec_lines = False
        
        if type(only_show_control_spec_violations) != bool:
            only_show_control_spec_violations = False

        # Save to class variable
        Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION = plotconfig_datasetLabelRotation
        Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN = plotconfig_showMedian
        Setting.OPTS_PLOTCONFIG_SHOW_CPK = plotconfig_showCpk
        Setting.OPTS_PLOTCONFIG_SHOW_N = plotconfig_showN
        Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN = plotconfig_showViolin
        Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL = plotconfig_showIndividual
        Setting.OPTS_PLOTCONFIG_USE_GRADIENT = plotconfig_useGradient
        Setting.OPTS_MEDIAN_FONT_SIZE = plotconfig_medianFontSize
        Setting.OPTS_PLOT_TITLE_FONT_SIZE = plotconfig_titleFontSize
        Setting.OPTS_DATASET_LABEL_FONT_SIZE = plotconfig_datasetLabelFontSize
        Setting.OPTS_PLOTCONFIG_TEXT_POSITION = plotconfig_textPosition
        Setting.OPTS_DATA_COUNT_METHOD = plotconfig_dataCountMethod
        Setting.OPTS_DATACONFIG_IMPORT_SKIP_ROW = dataconfig_importSkipRows
        Setting.OPTS_CONTROL_SPEC_REF_FILE = control_spec_ref_file
        Setting.OPTS_CONTROL_SPEC_VALUE = control_spec_value
        Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS = highlight_control_spec_violations
        Setting.OPTS_SHOW_CONTROL_SPEC_LINES = show_control_spec_lines
        Setting.OPTS_ONLY_SHOW_CONTROL_SPEC_VIOLATIONS = only_show_control_spec_violations

        # Save to local file
        self.cfgparser["OPTION"]["DATASET_LABEL_ROTATION"] = str(plotconfig_datasetLabelRotation)
        self.cfgparser["OPTION"]["PLOT_SHOW_MEDIAN"] = str(plotconfig_showMedian)
        self.cfgparser["OPTION"]["PLOT_SHOW_CPK"] = str(plotconfig_showCpk)
        self.cfgparser["OPTION"]["PLOT_SHOW_N"] = str(plotconfig_showN)
        self.cfgparser["OPTION"]["PLOT_SHOW_VIOLIN"] = str(plotconfig_showViolin)
        self.cfgparser["OPTION"]["PLOT_SHOW_INDIVIDUAL"] = str(plotconfig_showIndividual)
        self.cfgparser["OPTION"]["PLOT_USE_GRADIENT"] = str(plotconfig_useGradient)
        self.cfgparser["OPTION"]["MEDIAN_FONT_SIZE"] = str(plotconfig_medianFontSize)
        self.cfgparser["OPTION"]["PLOT_TITLE_FONT_SIZE"] = str(plotconfig_titleFontSize)
        self.cfgparser["OPTION"]["DATASET_LABEL_FONT_SIZE"] = str(plotconfig_datasetLabelFontSize)
        self.cfgparser["OPTION"]["TEXT_POSITION"] = plotconfig_textPosition
        self.cfgparser["OPTION"]["DATA_COUNT_METHOD"] = str(plotconfig_dataCountMethod)

        # Save Control Spec Line settings
        self.cfgparser["OPTION"]["CONTROL_SPEC_REF_FILE"] = control_spec_ref_file
        self.cfgparser["OPTION"]["CONTROL_SPEC_VALUE"] = control_spec_value
        self.cfgparser["OPTION"]["HIGHLIGHT_CONTROL_SPEC_VIOLATIONS"] = str(highlight_control_spec_violations)
        self.cfgparser["OPTION"]["SHOW_CONTROL_SPEC_LINES"] = str(show_control_spec_lines)
        self.cfgparser["OPTION"]["ONLY_SHOW_CONTROL_SPEC_VIOLATIONS"] = str(only_show_control_spec_violations)

        if dataconfig_importSkipRows == None:
            self.cfgparser["OPTION"]["DATA_IMPORT_SKIP_ROW_NUMBER"] = "None"
        else:
            self.cfgparser["OPTION"]["DATA_IMPORT_SKIP_ROW_NUMBER"] = " ".join(
                map(str, dataconfig_importSkipRows))

        with open(Setting.OPTS_LOCAL_FILENAME, 'w', encoding='utf-8') as configfile:
            self.cfgparser.write(configfile)
            configfile.close()

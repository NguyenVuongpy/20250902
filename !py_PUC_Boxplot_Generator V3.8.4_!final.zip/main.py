import sys
from PyQt6.QtWidgets import QApplication
from mvc_view import View
from mvc_controller import Controller
from mvc_model import Model
import view.rc.icons_rc 


'''
Main Program
'''
if __name__ == "__main__":
    app = QApplication(sys.argv)
    view = View()
    model = Model()
    mainController = Controller(model=model, view=view)

    sys.exit(app.exec()) 

from PyQt6.QtWidgets import QWidget
from view.ui.About_ui import Ui_About
from PyQt6.QtCore import pyqtSignal

# GUI About form
class WidgetAbout(QWidget):
    aboutClosed = pyqtSignal() # Thêm signal này

    def __init__(self):
        super(WidgetAbout, self).__init__()
        self.ui = Ui_About()
        self.ui.setupUi(self)

        # binding UI element trigger signal to action
        self.ui.btnOK_ToClose.clicked.connect(self.close)

    def closeEvent(self, event):
        self.aboutClosed.emit() # Phát ra tín hiệu khi cửa sổ đóng
        super().closeEvent(event)
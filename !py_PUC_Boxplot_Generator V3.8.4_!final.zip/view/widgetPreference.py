from PyQt6.QtWidgets import QWidget, QCheckBox
from PyQt6.QtCore import QRegularExpression, pyqtSignal
from PyQt6.QtGui import QRegularExpressionValidator
from view.ui.Preference_ui import Ui_Preference
from typing import List
from controller.setting import Setting


class WidgetPreference(QWidget):
    savePreference = pyqtSignal()  # Tạo một signal mới
    preferenceClosed = pyqtSignal() # Thêm signal này

    def __init__(self):
        super(WidgetPreference, self).__init__()
        self.ui = Ui_Preference()
        self.ui.setupUi(self)

        # Set the custom validator for the line edit
        digit_space_validator = DigitSpaceValidator()
        self.ui.lineEdit_dataConfigImportSkipRows.setValidator(
            digit_space_validator)

        self.ui.btnSave.clicked.connect(self.savePreference.emit)

        # Control Spec Line settings
        self.ui.checkBox_highlightControlSpecViolations.setChecked(Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS)
        self.ui.checkBox_showControlSpecLines.setChecked(Setting.OPTS_SHOW_CONTROL_SPEC_LINES)
        self.ui.checkBox_onlyShowControlSpecViolations.setChecked(Setting.OPTS_ONLY_SHOW_CONTROL_SPEC_VIOLATIONS)
        
        # Set control spec value combo box
        current_value = Setting.OPTS_CONTROL_SPEC_VALUE
        if current_value in ["±1.5σ", "±2.5σ", "±2σ", "±2.5σ", "±3σ", "±3.5σ", "±4σ"]:
            self.ui.comboBox_controlSpecValue.setCurrentText(current_value)
        else:
            self.ui.comboBox_controlSpecValue.setCurrentText("±1.5σ")
        
        # Set reference file combo box
        current_ref_file = Setting.OPTS_CONTROL_SPEC_REF_FILE
        if current_ref_file != "None":
            # Add the current reference file if it's not already in the combo box
            if self.ui.comboBox_controlSpecRefFile.findText(current_ref_file) == -1:
                self.ui.comboBox_controlSpecRefFile.addItem(current_ref_file)
            self.ui.comboBox_controlSpecRefFile.setCurrentText(current_ref_file)
        else:
            self.ui.comboBox_controlSpecRefFile.setCurrentText("None")

    def getUI_preference(self):
        dataset_label_rotation = int(self.ui.comboBox_datasetLabelRotation.currentText())
        show_median = self.ui.checkBox_showMedian.isChecked()
        show_cpk = self.ui.checkBox_showCpk.isChecked()
        show_n = self.ui.checkBox_showN.isChecked()
        show_violin = self.ui.checkBox_showViolin.isChecked()
        show_individual = self.ui.checkBox_showIndividual.isChecked()
        use_gradient = self.ui.checkBox_useGradientColors.isChecked()
        median_size = int(self.ui.comboBox_plotConfigMedianFontSize.currentText())
        title_size = int(self.ui.comboBox_plotTitleFontSize.currentText())
        text_position = self.ui.comboBox_textPosition.currentText()
        data_count_method = self.ui.comboBox_dataCountMethod.currentText()
        skiprows = self.ui.lineEdit_dataConfigImportSkipRows.text()
        if skiprows == 'None':
            skiprows = None
        else:
            skiprows = skiprows.split(' ')
            skiprows = [int(num) for num in skiprows if num.isnumeric()]
            skiprows = [row for row in skiprows if row >= 0]
            if len(skiprows) == 0:
                skiprows = None

        # Thêm vào hàm get
        dataset_label_size = int(self.ui.comboBox_datasetLabelFontSize.currentText())

        # Control Spec Line settings
        control_spec_ref_file = self.ui.comboBox_controlSpecRefFile.currentText()
        control_spec_value = self.ui.comboBox_controlSpecValue.currentText()
        highlight_control_spec_violations = self.ui.checkBox_highlightControlSpecViolations.isChecked()
        show_control_spec_lines = self.ui.checkBox_showControlSpecLines.isChecked()
        only_show_control_spec_violations = self.ui.checkBox_onlyShowControlSpecViolations.isChecked()

        return (dataset_label_rotation, show_median, show_cpk, show_n, show_violin, 
                show_individual, use_gradient, median_size, title_size, skiprows, 
                dataset_label_size,
                text_position, data_count_method, control_spec_ref_file, control_spec_value,
                highlight_control_spec_violations, show_control_spec_lines,
                only_show_control_spec_violations)

    def setUI_preference(
        self,
        dataset_label_rotation: int,
        show_median: bool,
        show_cpk: bool,
        show_n: bool,
        show_violin: bool,
        show_individual: bool,
        use_gradient: bool,
        median_fontsize: int,
        title_fontsize: int,
        rowskip: List[int],
        dataset_label_fontsize: int = 5,
        text_position: str = "Default",
        data_count_method: str = "Short_SN",
        control_spec_ref_file: str = "None",
        control_spec_value: str = "±1.5σ",
        highlight_control_spec_violations: bool = False,
        show_control_spec_lines: bool = False,
        only_show_control_spec_violations: bool = False
    ) -> None:
        # Data validation
        if type(dataset_label_rotation) != int:
            dataset_label_rotation = 0
        else:
            if not dataset_label_rotation in [0, 45, 90]:
                dataset_label_rotation = 0

        if type(median_fontsize) != int:
            median_fontsize = 4
        else:
            if not median_fontsize in range(2, 11):
                median_fontsize = 4

        if type(title_fontsize) != int:
            title_fontsize = 6
        else:
            if not title_fontsize in range(2, 11):
                title_fontsize = 6

        if rowskip != None:
            rowskip = [num for num in rowskip if type(num) == int]
            rowskip = [num for num in rowskip if num >= 0]
            if len(rowskip) == 0:
                rowskip = None

        # Set UI
        try:
            self.ui.comboBox_datasetLabelRotation.setCurrentText(
                str(dataset_label_rotation))
        except:
            self.ui.comboBox_datasetLabelRotation.setCurrentIndex(0)

        self.ui.checkBox_showMedian.setChecked(show_median)
        self.ui.checkBox_showCpk.setChecked(show_cpk)
        self.ui.checkBox_showN.setChecked(show_n)
        self.ui.checkBox_showViolin.setChecked(show_violin)
        self.ui.checkBox_showIndividual.setChecked(show_individual)
        self.ui.checkBox_useGradientColors.setChecked(use_gradient)

        try:
            self.ui.comboBox_plotConfigMedianFontSize.setCurrentText(
                str(median_fontsize))
        except:
            self.ui.comboBox_plotConfigMedianFontSize.setCurrentIndex(0)

        try:
            self.ui.comboBox_plotTitleFontSize.setCurrentText(str(title_fontsize))
        except:
            self.ui.comboBox_plotTitleFontSize.setCurrentIndex(4)

        if rowskip == None:
            self.ui.lineEdit_dataConfigImportSkipRows.setText('None')
        else:
            self.ui.lineEdit_dataConfigImportSkipRows.setText(
                ' '.join(map(str, rowskip)))

        try:
            self.ui.comboBox_datasetLabelFontSize.setCurrentText(str(dataset_label_fontsize))
        except:
            self.ui.comboBox_datasetLabelFontSize.setCurrentIndex(3)  # Default to 5

        try:
            self.ui.comboBox_textPosition.setCurrentText(text_position)
        except:
            self.ui.comboBox_textPosition.setCurrentIndex(0)

        try:
            self.ui.comboBox_dataCountMethod.setCurrentText(data_count_method)
        except:
            self.ui.comboBox_dataCountMethod.setCurrentIndex(0)

        # Set Control Spec Line settings
        self.ui.checkBox_highlightControlSpecViolations.setChecked(highlight_control_spec_violations)
        self.ui.checkBox_showControlSpecLines.setChecked(show_control_spec_lines)
        self.ui.checkBox_onlyShowControlSpecViolations.setChecked(only_show_control_spec_violations)

        try:
            self.ui.comboBox_controlSpecValue.setCurrentText(control_spec_value)
        except:
            self.ui.comboBox_controlSpecValue.setCurrentText("±1.5σ")

        # Set reference file combo box
        if control_spec_ref_file != "None":
            if self.ui.comboBox_controlSpecRefFile.findText(control_spec_ref_file) == -1:
                self.ui.comboBox_controlSpecRefFile.addItem(control_spec_ref_file)
            self.ui.comboBox_controlSpecRefFile.setCurrentText(control_spec_ref_file)
        else:
            self.ui.comboBox_controlSpecRefFile.setCurrentText("None")

        return None

    def update_reference_file_list(self, file_list: List[str]):
        """Cập nhật danh sách file reference trong combo box"""
        current_selection = self.ui.comboBox_controlSpecRefFile.currentText()
        
        # Clear existing items except "None"
        self.ui.comboBox_controlSpecRefFile.clear()
        self.ui.comboBox_controlSpecRefFile.addItem("None")
        
        # Add new files
        for file_name in file_list:
            self.ui.comboBox_controlSpecRefFile.addItem(file_name)
        
        # Restore previous selection if it still exists
        if current_selection and current_selection != "None":
            index = self.ui.comboBox_controlSpecRefFile.findText(current_selection)
            if index >= 0:
                self.ui.comboBox_controlSpecRefFile.setCurrentIndex(index)
            else:
                self.ui.comboBox_controlSpecRefFile.setCurrentIndex(0)  # "None"
        else:
            self.ui.comboBox_controlSpecRefFile.setCurrentIndex(0)  # "None"

    def closeEvent(self, event):
        self.preferenceClosed.emit() # Phát ra tín hiệu khi cửa sổ đóng
        super().closeEvent(event)


class DigitSpaceValidator(QRegularExpressionValidator):
    """
    Custom validator class to set Validator for Line Edit to only accept digits and space characters
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        # Regular expression to match digits and space characters only
        regex = QRegularExpression("[0-9 ]*")
        self.setRegularExpression(regex)

    def validate(self, input, pos):
        # Use the regular expression validation
        return super().validate(input, pos)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from PyQt6 import QtGui
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QRadioButton, 
                            QButtonGroup, QSpinBox, QDialogButtonBox, QMessageBox,
                            QMenu, QGraphicsDropShadowEffect)
from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QIcon, QDesktopServices, QFont, QColor, QAction
import os
from controller.setting import Setting

class CPKProcessor:
    database = None
    figureconfig_list = None
    list_figures = None
    _cpk_data = None
    _error_data = None
    _dataset_labels = None
    _df_cpk = None
    _df_error = None

    @staticmethod
    def set_data(database, figureconfig_list, list_figures):
        """Thiết lập dữ liệu cho CPKProcessor"""
        CPKProcessor.database = database
        CPKProcessor.figureconfig_list = figureconfig_list
        CPKProcessor.list_figures = list_figures
        # Reset các biến cache
        CPKProcessor._cpk_data = None
        CPKProcessor._error_data = None
        CPKProcessor._dataset_labels = None
        CPKProcessor._df_cpk = None
        CPKProcessor._df_error = None

    @staticmethod
    def _get_dataset_labels():
        """Lấy labels của dataset từ figure đầu tiên"""
        if CPKProcessor._dataset_labels is None:
            if CPKProcessor.list_figures:
                _, first_fig = CPKProcessor.list_figures[0]
                first_ax = first_fig.get_axes()[0]
                CPKProcessor._dataset_labels = [label.get_text() for label in first_ax.get_xticklabels()]
            else:
                CPKProcessor._dataset_labels = []
        return CPKProcessor._dataset_labels

    @staticmethod
    def _get_cpk_data():
        """Lấy dữ liệu CPK, tính toán nếu chưa có"""
        if CPKProcessor._cpk_data is None:
            CPKProcessor._cpk_data, _ = CPKProcessor.collect_cpk_data(
                CPKProcessor.database,
                CPKProcessor.figureconfig_list,
                CPKProcessor.list_figures
            )
        return CPKProcessor._cpk_data

    @staticmethod
    def _get_error_data():
        """Lấy dữ liệu tỷ lệ lỗi, tính toán nếu chưa có"""
        if CPKProcessor._error_data is None:
            CPKProcessor._error_data, _ = CPKProcessor.collect_error_rate_data(
                CPKProcessor.database,
                CPKProcessor.figureconfig_list,
                CPKProcessor.list_figures
            )
        return CPKProcessor._error_data

    @staticmethod
    def _prepare_dataframes():
        """Chuẩn bị DataFrames cho việc xuất Excel"""
        if CPKProcessor._df_cpk is None or CPKProcessor._df_error is None:
            # Lấy dữ liệu
            cpk_data = CPKProcessor._get_cpk_data()
            error_data = CPKProcessor._get_error_data()
            dataset_labels = CPKProcessor._get_dataset_labels()

            # Tạo DataFrames
            CPKProcessor._df_cpk = pd.DataFrame.from_dict(cpk_data, orient='index', columns=dataset_labels)
            CPKProcessor._df_error = pd.DataFrame.from_dict(error_data, orient='index', columns=dataset_labels)

            # Lấy thông tin Figure
            figure_info = CPKProcessor.get_figure_info(CPKProcessor.figureconfig_list)
            
            # Thêm cột Figure
            CPKProcessor._df_cpk['Figure'] = CPKProcessor._df_cpk.index.map(figure_info)
            CPKProcessor._df_error['Figure'] = CPKProcessor._df_error.index.map(figure_info)
            
            # Reset index và sắp xếp cột
            CPKProcessor._df_cpk = CPKProcessor._df_cpk.reset_index().rename(columns={'index': 'Plot Item'})
            CPKProcessor._df_error = CPKProcessor._df_error.reset_index().rename(columns={'index': 'Plot Item'})
            
            cols = ['Figure', 'Plot Item'] + [col for col in CPKProcessor._df_cpk.columns if col not in ['Figure', 'Plot Item']]
            CPKProcessor._df_cpk = CPKProcessor._df_cpk[cols]
            CPKProcessor._df_error = CPKProcessor._df_error[cols]

    @staticmethod
    def calculate_cpk(data, lsl, usl):
        """Tính toán giá trị CPK cho một tập dữ liệu"""
        if len(data) == 0:
            return None
            
        mean = np.mean(data)
        std = np.std(data)
        cpk = None  # Initialize cpk variable
        
        if std == 0:
            return None
            
        # Calculate CPK if specs exist
        if lsl is not None or usl is not None:
            mean = np.mean(data)
            std = np.std(data)
            if std > 0:
                if usl is not None and lsl is not None:
                    if usl == 100:
                        cpk = (mean - lsl) / (3 * std)  # Chỉ tính theo LSL
                    elif usl == 0:
                        cpk = (mean - lsl) / (3 * std)  # Chỉ tính theo LSL
                    elif lsl == 0:
                        cpk = (usl - mean) / (3 * std)  # Chỉ tính theo USL
                    else:
                        cpk = min((usl - mean) / (3 * std), (mean - lsl) / (3 * std))
                elif usl is None and lsl is not None:
                    cpk = (mean - lsl) / (3 * std) 
                elif usl is not None and lsl is None:
                    cpk = (usl - mean) / (3 * std) 
            
        return round(cpk, 4) if cpk is not None else None

    @staticmethod
    def collect_cpk_data(database, figureconfig_list, list_figures):
        """Thu thập dữ liệu CPK từ database và figureconfig"""
        cpk_data = {}
        dataset_labels = []
        
        if list_figures:
            _, first_fig = list_figures[0]
            first_ax = first_fig.get_axes()[0]
            dataset_labels = [label.get_text() for label in first_ax.get_xticklabels()]

        for fig_name, fig in list_figures:
            for ax in fig.get_axes():
                plot_title = ax.get_title()
                
                found_config = None
                for figconfig in figureconfig_list:
                    for plotconfig in figconfig.plotconfig_list:
                        if plotconfig.title == plot_title and plotconfig.to_plot:
                            found_config = plotconfig
                            break
                    if found_config:
                        break
                        
                if not found_config:
                    continue

                plot_dataset = database.from_column(
                    column=found_config.item_name,
                    removeNaN=True,
                    sort_data_order_by=dataset_labels
                )
                
                if plot_dataset is None:
                    continue
                    
                lsl = found_config.lowerspec
                usl = found_config.upperspec

                cpk_values = [None] * len(dataset_labels)
                for i, (name, (status, data)) in enumerate(plot_dataset.items()):
                    if status == 'has_data' and len(data) > 0:
                        cpk_values[i] = CPKProcessor.calculate_cpk(data, lsl, usl)

                cpk_data[plot_title] = cpk_values

        return cpk_data, dataset_labels

    @staticmethod
    def create_cpk_heatmap(df, dataset_labels, num_heatmaps, MAX_ROWS_PER_HEATMAP):
        """Tạo heatmap cho dữ liệu CPK"""
        # Chuẩn bị dữ liệu
        CPKProcessor._prepare_dataframes()
        
        # Tạo heatmap
        return CPKProcessor._create_cpk_heatmap(
            CPKProcessor._df_cpk,
            dataset_labels,
            num_heatmaps,
            MAX_ROWS_PER_HEATMAP
        )

    @staticmethod
    def _create_cpk_heatmap(df, dataset_labels, num_heatmaps, MAX_ROWS_PER_HEATMAP):
        """Internal method to create heatmap"""
        heatmap_files = []
        total_rows = len(df)

        # Chỉ lấy các cột số liệu (bỏ qua cột Figure và Plot Item)
        numeric_df = df.select_dtypes(include=[np.number])

        for i in range(num_heatmaps):
            start_idx = i * MAX_ROWS_PER_HEATMAP
            end_idx = min((i + 1) * MAX_ROWS_PER_HEATMAP, total_rows)
            df_subset = numeric_df.iloc[start_idx:end_idx]

            n_rows, n_cols = df_subset.shape
            min_cell_size = 0.3
            fig_width = max(12, min_cell_size * n_cols)
            fig_height = max(8, min_cell_size * n_rows)
            fig_width = min(fig_width, 30)
            fig_height = min(fig_height, 20)

            plt.figure(figsize=(fig_width, fig_height))
            gs = plt.GridSpec(1, 20)
            ax_heatmap = plt.subplot(gs[0, :-2])
            ax_cbar = plt.subplot(gs[0, -1])

            # Tạo mask cho các giá trị NaN
            mask = pd.isna(df_subset)

            sns.heatmap(df_subset,
                       ax=ax_heatmap,
                       cbar_ax=ax_cbar,
                       annot=True,
                       fmt='.2f',
                       cmap='RdYlGn',
                       center=1.33,
                       vmin=0,
                       vmax=2.66,
                       cbar_kws={'label': 'CPK Value'},
                       mask=mask,
                       annot_kws={"size": max(6, min(8, 300/max(n_rows, n_cols)))},
                       linewidths=0.5,
                       linecolor='gray')

            # Sử dụng index của df gốc để lấy tên Plot Item
            plot_items = df.iloc[start_idx:end_idx]['Plot Item']
            ax_heatmap.set_yticklabels(plot_items, rotation=0)

            ax_heatmap.set_xticklabels(dataset_labels, rotation=45, ha='right')
            plt.setp(ax_heatmap.get_xticklabels(), fontsize=8)
            ax_heatmap.tick_params(axis='x', which='major', pad=8)

            plt.setp(ax_heatmap.get_yticklabels(), fontsize=8)
            ax_heatmap.tick_params(axis='y', which='major', pad=8)

            plt.subplots_adjust(bottom=0.2, left=0.2, right=0.85, top=0.9)

            part_title = f"CPK Values Heatmap"
            if num_heatmaps > 1:
                part_title += f" - Part {i+1}/{num_heatmaps} (Items {start_idx+1}-{end_idx})"
            plt.suptitle(part_title, y=1.02, fontsize=14)

            ax_heatmap.set_xlabel('Dataset', fontsize=10, labelpad=10)
            ax_heatmap.set_ylabel('Plot Item', fontsize=10, labelpad=10)

            plt.tight_layout()

            output_path = os.path.join(Setting.OUTPUT_DIR, f"CPK_Heatmap_Part{i+1}.png")
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            heatmap_files.append(output_path)

        return heatmap_files

    @staticmethod
    def show_export_success_dialog(heatmap_files):
        """Hiển thị hộp thoại thông báo xuất thành công"""
        msg_box = QMessageBox()
        msg_box.setWindowTitle("Export Success")
        icon = QIcon()
        icon.addPixmap(QtGui.QPixmap(":/icons/icon_main.png"))
        msg_box.setWindowIcon(icon)
        msg_box.setIcon(QMessageBox.Icon.Information)
        
        if len(heatmap_files) == 1:
            msg_box.setText(f"CPK heatmap has been exported to:\n{heatmap_files[0]}")
        else:
            msg_text = "CPK heatmaps have been exported to:\n"
            msg_text += "\n".join(heatmap_files)
            msg_box.setText(msg_text)

        buttons = []
        for i, file_path in enumerate(heatmap_files):
            button_text = f"Open Part {i+1}"
            button = msg_box.addButton(button_text, QMessageBox.ButtonRole.ActionRole)
            buttons.append((button, file_path))
        
        ok_button = msg_box.addButton(QMessageBox.StandardButton.Ok)
        msg_box.setDefaultButton(ok_button)
        
        result = msg_box.exec()
        
        clicked_button = msg_box.clickedButton()
        for button, file_path in buttons:
            if clicked_button == button:
                QDesktopServices.openUrl(QUrl.fromLocalFile(file_path))

    @staticmethod
    def calculate_error_rate(data, lsl, usl):
        """Tính tỷ lệ lỗi dựa trên LSL và USL"""
        if len(data) == 0:
            return None
            
        error_count = 0
        for value in data:
            if (lsl is not None and value < lsl) or (usl is not None and value > usl):
                error_count += 1
                
        return round(error_count / len(data) * 100, 2) if len(data) > 0 else None

    @staticmethod
    def collect_error_rate_data(database, figureconfig_list, list_figures):
        """Thu thập dữ liệu tỷ lệ lỗi từ database và figureconfig"""
        error_data = {}
        dataset_labels = []
        
        if list_figures:
            _, first_fig = list_figures[0]
            first_ax = first_fig.get_axes()[0]
            dataset_labels = [label.get_text() for label in first_ax.get_xticklabels()]

        for fig_name, fig in list_figures:
            for ax in fig.get_axes():
                plot_title = ax.get_title()
                
                found_config = None
                for figconfig in figureconfig_list:
                    for plotconfig in figconfig.plotconfig_list:
                        if plotconfig.title == plot_title and plotconfig.to_plot:
                            found_config = plotconfig
                            break
                    if found_config:
                        break
                        
                if not found_config:
                    continue

                plot_dataset = database.from_column(
                    column=found_config.item_name,
                    removeNaN=True,
                    sort_data_order_by=dataset_labels
                )
                
                if plot_dataset is None:
                    continue
                    
                lsl = found_config.lowerspec
                usl = found_config.upperspec

                error_rates = [None] * len(dataset_labels)
                for i, (name, (status, data)) in enumerate(plot_dataset.items()):
                    if status == 'has_data' and len(data) > 0:
                        error_rates[i] = CPKProcessor.calculate_error_rate(data, lsl, usl)

                error_data[plot_title] = error_rates

        return error_data, dataset_labels

    @staticmethod
    def get_figure_info(figureconfig_list):
        """Lấy thông tin Figure cho mỗi Plot Item"""
        figure_info = {}
        for figconfig in figureconfig_list:
            for plotconfig in figconfig.plotconfig_list:
                if plotconfig.to_plot:
                    figure_info[plotconfig.title] = figconfig.name
        return figure_info

    @staticmethod
    def export_to_excel(output_path):
        """Xuất dữ liệu CPK và tỷ lệ lỗi ra file Excel với định dạng"""
        # Chuẩn bị dữ liệu
        CPKProcessor._prepare_dataframes()
        dataset_labels = CPKProcessor._get_dataset_labels()
        
        with pd.ExcelWriter(output_path, engine='xlsxwriter') as writer:
            # Sheet CPK Values
            CPKProcessor._df_cpk.to_excel(writer, sheet_name='CPK Values', index=False)
            # Sheet Error Rates
            CPKProcessor._df_error.to_excel(writer, sheet_name='Failure Rates', index=False)
            
            workbook = writer.book
            worksheet_cpk = writer.sheets['CPK Values']
            worksheet_error = writer.sheets['Failure Rates']
            
            # Định dạng các ô
            header_format = workbook.add_format({
                'bold': True,
                'align': 'center',
                'valign': 'vcenter',
                'bg_color': '#3498db',
                'font_color': 'white',
                'border': 1,
                'text_wrap': False
            })
            
            # Định dạng cho các giá trị CPK
            cpk_formats = {
                'red': workbook.add_format({
                    'bg_color': '#ff9999',
                    'align': 'center',
                    'num_format': '0.00',
                    'border': 1
                }),
                'yellow': workbook.add_format({
                    'bg_color': '#ffeb99',
                    'align': 'center',
                    'num_format': '0.00',
                    'border': 1
                }),
                'green': workbook.add_format({
                    'bg_color': '#99ff99',
                    'align': 'center',
                    'num_format': '0.00',
                    'border': 1
                })
            }

            # Định dạng cho các giá trị tỷ lệ lỗi với gradient màu
            error_format = workbook.add_format({
                'align': 'center',
                'num_format': '0.00%',
                'border': 1
            })
            
            # Định dạng cho cột Plot Item và Figure
            plot_item_format = workbook.add_format({
                'align': 'left',
                'valign': 'vcenter',
                'text_wrap': False,
                'border': 1,
                'bg_color': '#f8f9fa'
            })

            figure_format = workbook.add_format({
                'align': 'left',
                'valign': 'vcenter',
                'text_wrap': False,
                'border': 1,
                'bg_color': '#e3f2fd',  # Màu nền nhẹ để phân biệt
                'bold': True  # In đậm tên Figure
            })

            empty_figure_format = workbook.add_format({
                'border': 1,
                'bg_color': '#f8f9fa'
            })

            # Format cho sheet CPK Values
            for col_num, value in enumerate(['Figure', 'Plot Item'] + dataset_labels):
                worksheet_cpk.write(0, col_num, value, header_format)

            # Format cho sheet Error Rates
            for col_num, value in enumerate(['Figure', 'Plot Item'] + dataset_labels):
                worksheet_error.write(0, col_num, value, header_format)
            
            # Format CPK values với màu sắc
            prev_figure = None
            for row_num in range(len(CPKProcessor._df_cpk)):
                current_figure = CPKProcessor._df_cpk.iloc[row_num]['Figure']
                
                # Chỉ ghi Figure nếu khác với Figure trước đó
                if current_figure != prev_figure:
                    worksheet_cpk.write(row_num + 1, 0, current_figure, figure_format)
                    prev_figure = current_figure
                else:
                    worksheet_cpk.write(row_num + 1, 0, '', empty_figure_format)
                
                worksheet_cpk.write(row_num + 1, 1, CPKProcessor._df_cpk.iloc[row_num]['Plot Item'], plot_item_format)
                
                # Ghi các giá trị CPK
                for col_num, col in enumerate(dataset_labels):
                    value = CPKProcessor._df_cpk.iloc[row_num][col]
                    if pd.isna(value):
                        empty_format = workbook.add_format({
                            'border': 1,
                            'bg_color': '#f8f9fa'
                        })
                        worksheet_cpk.write(row_num + 1, col_num + 2, '', empty_format)
                        continue
                        
                    if value < 1.0:
                        cell_format = cpk_formats['red']
                    elif value < 1.33:
                        cell_format = cpk_formats['yellow']
                    else:
                        cell_format = cpk_formats['green']
                        
                    worksheet_cpk.write(row_num + 1, col_num + 2, value, cell_format)

            # Format Error Rates với màu sắc theo cột
            prev_figure = None
            for row_num in range(len(CPKProcessor._df_error)):
                current_figure = CPKProcessor._df_error.iloc[row_num]['Figure']
                
                # Chỉ ghi Figure nếu khác với Figure trước đó
                if current_figure != prev_figure:
                    worksheet_error.write(row_num + 1, 0, current_figure, figure_format)
                    prev_figure = current_figure
                else:
                    worksheet_error.write(row_num + 1, 0, '', empty_figure_format)
                
                worksheet_error.write(row_num + 1, 1, CPKProcessor._df_error.iloc[row_num]['Plot Item'], plot_item_format)

                for col_num, col in enumerate(dataset_labels):
                    value = CPKProcessor._df_error.iloc[row_num][col]
                    if pd.isna(value):
                        empty_format = workbook.add_format({
                            'border': 1,
                            'bg_color': '#f8f9fa'
                        })
                        worksheet_error.write(row_num + 1, col_num + 2, '', empty_format)
                        continue

                    try:
                        value = float(value)
                    except (ValueError, TypeError):
                        continue
                        
                    # Nếu giá trị là 0%, sử dụng màu trắng
                    if value == 0:
                        cell_format = workbook.add_format({
                            'align': 'center',
                            'num_format': '0.00%',
                            'border': 1,
                            'bg_color': 'white'  # Màu trắng cho 0%
                        })
                        worksheet_error.write(row_num + 1, col_num + 2, 0, cell_format)
                    else:
                        # Tính toán màu dựa trên vị trí của giá trị trong phạm vi của cột
                        col_values = CPKProcessor._df_error[col].dropna()
                        col_values = col_values[col_values > 0].astype(float)
                        
                        if len(col_values) > 0:
                            max_value = float(col_values.max())
                            min_value = float(col_values.min())
                            value_range = max_value - min_value if max_value != min_value else 1
                            
                            if max_value == min_value:
                                intensity = 1
                            else:
                                intensity = (value - min_value) / value_range

                            # Tạo màu gradient từ đỏ nhạt (255, 200, 200) đến đỏ đậm (255, 0, 0)
                            r = 255  # Luôn giữ đỏ tối đa
                            g = b = int(200 - (intensity * 200))  # Từ 200 xuống 0

                            cell_format = workbook.add_format({
                                'align': 'center',
                                'num_format': '0.00%',
                                'border': 1,
                                'bg_color': f'#{r:02x}{g:02x}{b:02x}'
                            })
                            worksheet_error.write(row_num + 1, col_num + 2, value/100, cell_format)
            
            # Tự động điều chỉnh độ rộng cột cho cả hai sheet
            for worksheet in [worksheet_cpk, worksheet_error]:
                # Độ rộng cho cột Figure
                figure_width = max(
                    len('Figure'),
                    max(len(str(x)) for x in CPKProcessor._df_cpk['Figure'] if pd.notna(x))
                ) + 2
                worksheet.set_column(0, 0, figure_width)
                
                # Độ rộng cho cột Plot Item
                plot_item_width = max(
                    len('Plot Item'),
                    max(len(str(x)) for x in CPKProcessor._df_cpk['Plot Item'] if pd.notna(x))
                ) + 2
                worksheet.set_column(1, 1, plot_item_width)
                
                # Độ rộng cho các cột dữ liệu
                for col_num, col in enumerate(dataset_labels):
                    header_width = len(str(col))
                    data_width = max(
                        len(f"{x:.2f}") if pd.notna(x) else 0
                        for x in CPKProcessor._df_cpk[col]
                    )
                    max_width = max(header_width, data_width) + 2
                    worksheet.set_column(col_num + 2, col_num + 2, max_width)
            
            # Thêm legend cho sheet CPK Values
            legend_col = len(dataset_labels) + 3  # +3 vì có thêm cột Figure và Plot Item
            legend_title_format = workbook.add_format({
                'bold': True,
                'font_size': 12,
                'align': 'left',
                'valign': 'vcenter',
                'border': 1
            })
            legend_format = workbook.add_format({
                'align': 'left',
                'valign': 'vcenter',
                'border': 1
            })
            
            # Legend cho CPK Values
            worksheet_cpk.merge_range(0, legend_col, 0, legend_col + 1, 'CPK Values Legend', legend_title_format)
            cpk_legend_items = [
                ('CPK < 1.0', 'Critical (Immediate Action Required)', cpk_formats['red']),
                ('1.0 ≤ CPK < 1.33', 'Warning (Monitoring Required)', cpk_formats['yellow']),
                ('CPK ≥ 1.33', 'Good (Process is Capable)', cpk_formats['green'])
            ]
            
            for i, (threshold, description, format) in enumerate(cpk_legend_items, 1):
                worksheet_cpk.write(i, legend_col, threshold, format)
                worksheet_cpk.write(i, legend_col + 1, description, legend_format)          
            # Thiết lập độ rộng cột cho legend
            for worksheet in [worksheet_cpk, worksheet_error]:
                threshold_width = max(len(item[0]) for item in cpk_legend_items)
                description_width = max(len(item[1]) for item in cpk_legend_items)
                
                worksheet.set_column(legend_col - 1, legend_col - 1, 2)
                worksheet.set_column(legend_col, legend_col, threshold_width + 2)
                worksheet.set_column(legend_col + 1, legend_col + 1, description_width + 2)
                
                worksheet.freeze_panes(1, 2)  # Freeze cả cột Figure và Plot Item

            # Tạo sheet phân tích tổng hợp CPK
            # Nhóm theo Figure và tính CPK nhỏ nhất cho mỗi dataset
            summary_df = CPKProcessor._df_cpk.groupby('Figure').agg({
                col: lambda x: x.min() if not x.isna().all() else None 
                for col in dataset_labels
            }).reset_index()
            
            # Sắp xếp lại thứ tự Figure theo thứ tự trong figureconfig_list
            figure_order = [figconfig.name for figconfig in CPKProcessor.figureconfig_list]
            summary_df['Figure_order'] = summary_df['Figure'].map(lambda x: figure_order.index(x) if x in figure_order else len(figure_order))
            summary_df = summary_df.sort_values('Figure_order').drop('Figure_order', axis=1)
            
            # Xuất sheet Summary CPK
            summary_df.to_excel(writer, sheet_name='Summary CPK', index=False)
            worksheet_summary_cpk = writer.sheets['Summary CPK']
            
            # Format cho sheet Summary CPK
            for col_num, value in enumerate(['Figure'] + dataset_labels):
                worksheet_summary_cpk.write(0, col_num, value, header_format)
            
            # Format các giá trị CPK trong sheet Summary CPK
            for row_num in range(len(summary_df)):
                worksheet_summary_cpk.write(row_num + 1, 0, summary_df.iloc[row_num]['Figure'], figure_format)
                
                for col_num, col in enumerate(dataset_labels):
                    value = summary_df.iloc[row_num][col]
                    if pd.isna(value):
                        empty_format = workbook.add_format({
                            'border': 1,
                            'bg_color': '#f8f9fa'
                        })
                        worksheet_summary_cpk.write(row_num + 1, col_num + 1, '', empty_format)
                        continue
                        
                    if value < 1.0:
                        cell_format = cpk_formats['red']
                    elif value < 1.33:
                        cell_format = cpk_formats['yellow']
                    else:
                        cell_format = cpk_formats['green']
                        
                    worksheet_summary_cpk.write(row_num + 1, col_num + 1, value, cell_format)
            
            # Điều chỉnh độ rộng cột cho sheet Summary CPK
            figure_width = max(
                len('Figure'),
                max(len(str(x)) for x in summary_df['Figure'] if pd.notna(x))
            ) + 2
            worksheet_summary_cpk.set_column(0, 0, figure_width)
            
            for col_num, col in enumerate(dataset_labels):
                header_width = len(str(col))
                data_width = max(
                    len(f"{x:.2f}") if pd.notna(x) else 0
                    for x in summary_df[col]
                )
                max_width = max(header_width, data_width) + 2
                worksheet_summary_cpk.set_column(col_num + 1, col_num + 1, max_width)
            
            # Freeze pane cho sheet Summary CPK
            worksheet_summary_cpk.freeze_panes(1, 1)
            
            # Thêm legend cho sheet Summary CPK
            legend_col = len(dataset_labels) + 3  # +3 vì có thêm cột Figure
            worksheet_summary_cpk.merge_range(0, legend_col, 0, legend_col + 1, 'CPK Values Legend', legend_title_format)
            for i, (threshold, description, format) in enumerate(cpk_legend_items, 1):
                worksheet_summary_cpk.write(i, legend_col, threshold, format)
                worksheet_summary_cpk.write(i, legend_col + 1, description, legend_format)
            
            # Thiết lập độ rộng cột cho legend của sheet Summary CPK
            threshold_width = max(len(item[0]) for item in cpk_legend_items)
            description_width = max(len(item[1]) for item in cpk_legend_items)
            
            worksheet_summary_cpk.set_column(legend_col - 1, legend_col - 1, 2)
            worksheet_summary_cpk.set_column(legend_col, legend_col, threshold_width + 2)
            worksheet_summary_cpk.set_column(legend_col + 1, legend_col + 1, description_width + 2)

            # Tạo sheet phân tích tổng hợp Failure Rates
            # Nhóm theo Figure và tính tỷ lệ lỗi lớn nhất cho mỗi dataset
            summary_failure_df = CPKProcessor._df_error.groupby('Figure').agg({
                col: lambda x: x.max() if not x.isna().all() else None 
                for col in dataset_labels
            }).reset_index()
            
            # Sắp xếp lại thứ tự Figure theo thứ tự trong figureconfig_list
            summary_failure_df['Figure_order'] = summary_failure_df['Figure'].map(lambda x: figure_order.index(x) if x in figure_order else len(figure_order))
            summary_failure_df = summary_failure_df.sort_values('Figure_order').drop('Figure_order', axis=1)
            
            # Xuất sheet Summary Failure
            summary_failure_df.to_excel(writer, sheet_name='Summary Failure', index=False)
            worksheet_summary_failure = writer.sheets['Summary Failure']
            
            # Format cho sheet Summary Failure
            for col_num, value in enumerate(['Figure'] + dataset_labels):
                worksheet_summary_failure.write(0, col_num, value, header_format)
            
            # Format các giá trị tỷ lệ lỗi trong sheet Summary Failure
            for row_num in range(len(summary_failure_df)):
                worksheet_summary_failure.write(row_num + 1, 0, summary_failure_df.iloc[row_num]['Figure'], figure_format)
                
                for col_num, col in enumerate(dataset_labels):
                    value = summary_failure_df.iloc[row_num][col]
                    if pd.isna(value):
                        empty_format = workbook.add_format({
                            'border': 1,
                            'bg_color': '#f8f9fa'
                        })
                        worksheet_summary_failure.write(row_num + 1, col_num + 1, '', empty_format)
                        continue

                    try:
                        value = float(value)
                    except (ValueError, TypeError):
                        continue
                        
                    # Nếu giá trị là 0%, sử dụng màu trắng
                    if value == 0:
                        cell_format = workbook.add_format({
                            'align': 'center',
                            'num_format': '0.00%',
                            'border': 1,
                            'bg_color': 'white'  # Màu trắng cho 0%
                        })
                        worksheet_summary_failure.write(row_num + 1, col_num + 1, 0, cell_format)
                    else:
                        # Tính toán màu dựa trên vị trí của giá trị trong phạm vi của cột
                        col_values = CPKProcessor._df_error[col].dropna()
                        col_values = col_values[col_values > 0].astype(float)
                        
                        if len(col_values) > 0:
                            max_value = float(col_values.max())
                            min_value = float(col_values.min())
                            value_range = max_value - min_value if max_value != min_value else 1
                            
                            if max_value == min_value:
                                intensity = 1
                            else:
                                intensity = (value - min_value) / value_range

                            # Tạo màu gradient từ đỏ nhạt (255, 200, 200) đến đỏ đậm (255, 0, 0)
                            r = 255  # Luôn giữ đỏ tối đa
                            g = b = int(200 - (intensity * 200))  # Từ 200 xuống 0

                            cell_format = workbook.add_format({
                                'align': 'center',
                                'num_format': '0.00%',
                                'border': 1,
                                'bg_color': f'#{r:02x}{g:02x}{b:02x}'
                            })
                            worksheet_summary_failure.write(row_num + 1, col_num + 1, value/100, cell_format)
            
            # Điều chỉnh độ rộng cột cho sheet Summary Failure
            figure_width = max(
                len('Figure'),
                max(len(str(x)) for x in summary_failure_df['Figure'] if pd.notna(x))
            ) + 2
            worksheet_summary_failure.set_column(0, 0, figure_width)
            
            for col_num, col in enumerate(dataset_labels):
                header_width = len(str(col))
                data_width = max(
                    len(f"{x:.2f}") if pd.notna(x) else 0
                    for x in summary_failure_df[col]
                )
                max_width = max(header_width, data_width) + 2
                worksheet_summary_failure.set_column(col_num + 1, col_num + 1, max_width)
            
            # Freeze pane cho sheet Summary Failure
            worksheet_summary_failure.freeze_panes(1, 1)
            
            worksheet_summary_failure.set_column(legend_col - 1, legend_col - 1, 2)
            worksheet_summary_failure.set_column(legend_col, legend_col, threshold_width + 2)
            worksheet_summary_failure.set_column(legend_col + 1, legend_col + 1, description_width + 2)

    @staticmethod
    def show_excel_export_success_dialog(output_path):
        """Hiển thị hộp thoại thông báo xuất Excel thành công"""
        msg_box = QMessageBox()
        msg_box.setWindowTitle("Export Success")
        icon = QIcon()
        icon.addPixmap(QtGui.QPixmap(":/icons/icon_main.png"))
        msg_box.setWindowIcon(icon)
        msg_box.setIcon(QMessageBox.Icon.Information)
        msg_box.setText(f"CPK values have been exported to:\n{output_path}")
        
        open_button = msg_box.addButton("Open File", QMessageBox.ButtonRole.ActionRole)
        ok_button = msg_box.addButton(QMessageBox.StandardButton.Ok)
        msg_box.setDefaultButton(ok_button)
        
        result = msg_box.exec()
        
        if msg_box.clickedButton() == open_button:
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))

    @staticmethod
    def create_export_menu(parent, export_excel_callback, view_heatmap_callback):
        """Tạo menu context cho nút Export CPK"""
        menu = QMenu(parent)
        
        # Tùy chỉnh font chữ cho menu
        font = QFont("Arial", 10)
        menu.setFont(font)

        # Tạo hiệu ứng đổ bóng cho menu
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(3)
        shadow.setYOffset(3)
        shadow.setColor(QColor(0, 0, 0, 150))
        menu.setGraphicsEffect(shadow)

        # Áp dụng QSS (Qt Style Sheet) để tùy chỉnh giao diện menu
        menu.setStyleSheet("""
            QMenu {
                background-color: #2E3440;
                border: 1px solid #4C566A;
                padding: 5px;
                border-radius: 8px;
            }
            QMenu::item {
                padding: 8px 20px;
                color: white;
                font-size: 10pt;
                border-radius: 6px;
            }
            QMenu::item:selected {
                background-color: #5E81AC;
            }
        """)

        # Thêm các tùy chọn vào menu
        exportExcel = QAction("📗 Export to Excel", parent)
        exportExcel.triggered.connect(export_excel_callback)
        
        viewHeatmap = QAction("📈 View as Heatmap", parent)
        viewHeatmap.triggered.connect(view_heatmap_callback)

        # Thêm actions vào menu
        menu.addAction(exportExcel)
        menu.addAction(viewHeatmap)

        return menu

    @staticmethod
    def create_heatmap_options_dialog(parent, total_rows):
        """Tạo dialog cho phép người dùng chọn tùy chọn hiển thị heatmap"""
        dialog = QDialog(parent)
        dialog.setWindowTitle("CPK Heatmap Options")
        icon = QIcon()
        icon.addPixmap(QtGui.QPixmap(":/icons/icon_main.png"))
        dialog.setWindowIcon(icon)
        dialog.setMinimumWidth(300)

        layout = QVBoxLayout()

        # Tạo radio buttons cho các lựa chọn
        option_group = QButtonGroup(dialog)
        
        # Tùy chọn 1: Tất cả trong một heatmap
        all_in_one = QRadioButton("Show all items in one heatmap")
        option_group.addButton(all_in_one, 1)
        layout.addWidget(all_in_one)
        
        # Tùy chọn 2: Số lượng dòng mặc định (60)
        default_rows = QRadioButton("Use default (60 items per heatmap)")
        default_rows.setChecked(True)  # Đặt làm mặc định
        option_group.addButton(default_rows, 2)
        layout.addWidget(default_rows)
        
        # Tùy chọn 3: Số lượng dòng tùy chỉnh
        custom_rows = QRadioButton("Custom items per heatmap:")
        option_group.addButton(custom_rows, 3)
        
        # Trường nhập số lượng dòng tùy chỉnh
        custom_rows_input = QSpinBox()
        custom_rows_input.setMinimum(1)
        custom_rows_input.setMaximum(total_rows)
        custom_rows_input.setValue(min(30, total_rows))
        custom_rows_input.setEnabled(False)  # Mặc định bị tắt
        
        # Bật/tắt trường nhập khi radio button được chọn/bỏ chọn
        def toggle_custom_input():
            custom_rows_input.setEnabled(custom_rows.isChecked())
        
        custom_rows.toggled.connect(toggle_custom_input)
        
        # Layout ngang cho tùy chọn 3
        custom_layout = QHBoxLayout()
        custom_layout.addWidget(custom_rows)
        custom_layout.addWidget(custom_rows_input)
        layout.addLayout(custom_layout)
        
        # Nút OK và Cancel
        button_box = QDialogButtonBox()
        button_box.addButton(QDialogButtonBox.StandardButton.Ok)
        button_box.addButton(QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        layout.addWidget(button_box)
        
        dialog.setLayout(layout)
        
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return None
            
        # Xác định số lượng heatmap dựa trên lựa chọn của người dùng
        max_rows = 60  # Giá trị mặc định
        if all_in_one.isChecked():
            max_rows = total_rows  # Tất cả trong một heatmap
        elif custom_rows.isChecked():
            max_rows = custom_rows_input.value()  # Giá trị tùy chỉnh
            
        num_heatmaps = (total_rows + max_rows - 1) // max_rows
        
        return {
            'num_heatmaps': num_heatmaps,
            'max_rows': max_rows
        } 
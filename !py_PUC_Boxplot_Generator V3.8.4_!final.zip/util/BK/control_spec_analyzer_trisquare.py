import numpy as np
from typing import List, Dict, Tuple, Optional
from matplotlib.axes import Axes
import matplotlib.patches as mpatches
from controller.setting import Setting
from model.csv_database import CSV_Database
import pandas as pd
import math
from scipy import stats


class ControlSpecAnalyzer:
    """
    A utility class for analyzing and highlighting control spec violations in boxplots
    """
    
    def __init__(self):
        self.PINK_COLOR = "#FFB6C1"    # For CPK < 1.33
        self.ORANGE_COLOR = "#FFA500"  # For median out of control
        self.YELLOW_COLOR = "#FFFF00"  # For excessive outliers (beyond sigma limits)
        self.RED_COLOR = "#FF0000"     # For multiple violations
        self.NORMAL_COLOR = "none"     # For normal boxplots
        self.has_any_violation = False
        self.violation_plots = set()
        
    def calculate_control_limits(self, data_list: List[np.ndarray], plot_item_name: str, ref_file: str = "None",
                                 database: CSV_Database = None, sigma_level: str = "±1.5σ") -> Tuple[float, float]:
        """
        Calculate control limits from reference data or current data
        """
        data_for_calculation = []
        if ref_file != "None" and database and plot_item_name:
            # Get data for plot_item_name from only the ref_file
            ref_plot_data = database.from_column(
                column=plot_item_name,
                removeNaN=True,
                sort_data_order_by=[ref_file]  # Only get data from ref_file
            )
            if ref_plot_data and ref_file in ref_plot_data and ref_plot_data[ref_file][0] == 'has_data':
                data_for_calculation.extend(ref_plot_data[ref_file][1])
        else:
            # If ref_file is None or invalid, use all available data for the current plot_item
            for data in data_list:
                if len(data) > 0:
                    data_for_calculation.extend(data)
        
        if len(data_for_calculation) == 0:
            return 0, 0
            
        mean = np.mean(data_for_calculation)
        std = np.std(data_for_calculation)
        
        # Extract sigma value from string
        if sigma_level == "±1.5σ":
            sigma_multiplier = 1.5
        elif sigma_level == "±2σ":
            sigma_multiplier = 2.0
        elif sigma_level == "±2.5σ":
            sigma_multiplier = 2.5
        elif sigma_level == "±3σ":
            sigma_multiplier = 3.0
        elif sigma_level == "±3.5σ":
            sigma_multiplier = 3.5
        else:
            sigma_multiplier = 1.5  # Default
        
        lower_limit = mean - sigma_multiplier * std
        upper_limit = mean + sigma_multiplier * std
        
        return lower_limit, upper_limit
    
    def get_reference_data(self, plot_item_name: str, ref_file: str, database: CSV_Database) -> np.ndarray:
        """
        Get reference data for proportion comparison
        """
        if ref_file != "None" and database and plot_item_name:
            ref_plot_data = database.from_column(
                column=plot_item_name,
                removeNaN=True,
                sort_data_order_by=[ref_file]
            )
            if ref_plot_data and ref_file in ref_plot_data and ref_plot_data[ref_file][0] == 'has_data':
                return np.array(ref_plot_data[ref_file][1])
        return np.array([])
    
    def count_outliers_beyond_sigma(self, data: np.ndarray, lower_limit: float, upper_limit: float) -> int:
        """
        Count outliers beyond sigma control limits
        """
        if len(data) == 0 or lower_limit == 0 or upper_limit == 0:
            return 0
            
        return np.sum((data < lower_limit) | (data > upper_limit))
    
    def chi_square_outlier_test(self, ref_data: np.ndarray, test_data: np.ndarray, 
                              lower_limit: float, upper_limit: float, alpha: float = 0.05) -> bool:
        """
        Perform a Chi-square test to detect significant difference in outlier proportions.
        Returns True if test_data has significantly more outliers than expected based on reference data.
        """
        if len(ref_data) == 0 or len(test_data) == 0:
            return False
            
        # Count outliers and inliers in reference data
        ref_outliers = self.count_outliers_beyond_sigma(ref_data, lower_limit, upper_limit)
        ref_inliers = len(ref_data) - ref_outliers
        
        # Calculate expected outlier rate from reference data
        if len(ref_data) > 0:
            expected_outlier_rate = ref_outliers / len(ref_data)
        else:
            expected_outlier_rate = 0
        
        # Skip if no outliers expected or very low expected rate
        if expected_outlier_rate <= 0.001:
            return False
            
        # Count outliers and inliers in test data
        test_outliers = self.count_outliers_beyond_sigma(test_data, lower_limit, upper_limit)
        test_inliers = len(test_data) - test_outliers
        
        # Skip if no outliers in test data
        if test_outliers == 0:
            return False
            
        # Create contingency table
        # Observed: [test_outliers, test_inliers]
        # Expected: [expected_outliers, expected_inliers]
        expected_outliers = len(test_data) * expected_outlier_rate
        expected_inliers = len(test_data) * (1 - expected_outlier_rate)
        
        # Ensure expected values are at least 5 for Chi-square test validity
        if expected_outliers < 5 or expected_inliers < 5:
            return False
            
        # Perform Chi-square test
        try:
            # Calculate Chi-square statistic
            chi2 = ((test_outliers - expected_outliers) ** 2 / expected_outliers + 
                    (test_inliers - expected_inliers) ** 2 / expected_inliers)
            
            # Get p-value (1 degree of freedom for 2x2 table)
            p_value = 1 - stats.chi2.cdf(chi2, 1)
            
            # One-tailed test: we only care if test data has MORE outliers
            return p_value < alpha and test_outliers > expected_outliers
            
        except (ValueError, ZeroDivisionError):
            return False

    def analyze_and_highlight(self, ax: Axes, bp: dict, data_list: List[np.ndarray],
                              plot_item_name: str, plot_index: int = 0, lsl: float = None, usl: float = None,
                              ref_file: str = "None", database: CSV_Database = None,
                              sigma_level: str = "±1.5σ") -> bool:
        """
        Analyze boxplots and highlight control spec violations using statistical tests.
        Returns: True if any violations were found.
        """
        if not Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS:
            return False

        has_violation = False
        
        # Calculate control limits
        lower_limit, upper_limit = self.calculate_control_limits(data_list, plot_item_name, ref_file, database, sigma_level)
        
        # Get reference data for proportion comparison
        ref_data = self.get_reference_data(plot_item_name, ref_file, database)
        
        # Draw control spec lines if enabled
        if Setting.OPTS_SHOW_CONTROL_SPEC_LINES and lower_limit != 0 and upper_limit != 0:
            # Draw lower control limit line in orange
            ax.axhline(y=lower_limit, linewidth=0.5, color='orange', linestyle='--')
            # Add text for the lower control limit line - ONLY SHOW SIGMA LEVEL
            ax.text(ax.get_xlim()[1], lower_limit, sigma_level, 
                    verticalalignment='center', horizontalalignment='left',
                    color='orange', fontsize=6)
            
            # Draw upper control limit line in orange
            ax.axhline(y=upper_limit, linewidth=0.5, color='orange', linestyle='--')
            # Add text for the upper control limit line - ONLY SHOW SIGMA LEVEL
            ax.text(ax.get_xlim()[1], upper_limit, sigma_level, 
                    verticalalignment='center', horizontalalignment='left',
                    color='orange', fontsize=6)
        
        # Analyze each boxplot
        for i, data in enumerate(data_list):
            if len(data) == 0:
                continue
                
            color = self.NORMAL_COLOR
            violations = []
            
            # Check CPK violation
            if lsl is not None or usl is not None:
                mean = np.mean(data)
                std = np.std(data)
                if std > 0:
                    if usl is not None and lsl is not None:
                        if usl == 100:
                            cpk = (mean - lsl) / (3 * std)
                        elif usl == 0:
                            cpk = (mean - lsl) / (3 * std)
                        elif lsl == 0:
                            cpk = (usl - mean) / (3 * std)
                        else:
                            cpk = min((usl - mean) / (3 * std), (mean - lsl) / (3 * std))
                    elif usl is None and lsl is not None:
                        cpk = (mean - lsl) / (3 * std)
                    elif usl is not None and lsl is None:
                        cpk = (usl - mean) / (3 * std)
                    else:
                        cpk = None
                        
                    if cpk is not None and cpk < 1.33:
                        violations.append('cpk')
            
            # Check median violation
            if lower_limit != 0 and upper_limit != 0:
                median = np.median(data)
                if median < lower_limit or median > upper_limit:
                    violations.append('median')
            
            # Check outlier violation using Chi-square test
            if (lower_limit != 0 and upper_limit != 0 and len(ref_data) > 0 and 
                len(data) >= 10):  # Minimum sample size for meaningful Chi-square test
                
                has_excessive_outliers = self.chi_square_outlier_test(
                    ref_data, data, lower_limit, upper_limit, alpha=0.05
                )
                
                if has_excessive_outliers:
                    violations.append('outlier')
            
            # Set color based on violations
            if len(violations) >= 2:
                color = self.RED_COLOR
            elif 'cpk' in violations:
                color = self.PINK_COLOR
            elif 'median' in violations:
                color = self.ORANGE_COLOR
            elif 'outlier' in violations:
                color = self.YELLOW_COLOR
            
            # Apply highlighting
            if color != self.NORMAL_COLOR:
                box = bp['boxes'][i]
                box.set_facecolor(color)
                box.set_alpha(0.7)
                has_violation = True
                self.violation_plots.add(plot_index)
        
        if has_violation:
            self.has_any_violation = True
            
        return has_violation
    
    def is_plot_violation(self, plot_index: int) -> bool:
        """Check if the plot has a violation"""
        return plot_index in self.violation_plots
    
    def reset(self):
        """Reset the analyzer's state"""
        self.has_any_violation = False
        self.violation_plots.clear()
    
    def create_legend_elements(self):
        """Create legend elements for control spec violations"""
        elements = []
        
        if Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS:
            elements.append(mpatches.Patch(facecolor=self.PINK_COLOR, alpha=0.9, label='CPK < 1.33'))
            elements.append(mpatches.Patch(facecolor=self.ORANGE_COLOR, alpha=0.9, label='Med Out σ Line'))
            elements.append(mpatches.Patch(facecolor=self.YELLOW_COLOR, alpha=0.9, label='Excessive Outliers'))
            elements.append(mpatches.Patch(facecolor=self.RED_COLOR, alpha=0.9, label='Multiple Violations'))
        
        return elements
    
    def add_legend(self, ax: Axes):
        """Add a legend to the plot"""
        if self.has_any_violation:
            legend_elements = self.create_legend_elements()
            
            if legend_elements:
                # Calculate legend position
                bbox = ax.get_position()
                # Reduce plot width to make space for the legend
                ax.set_position([bbox.x0, bbox.y0, bbox.width * 0.85, bbox.height])
                
                # Add legend outside the plot
                ax.legend(handles=legend_elements,
                          loc='center left',
                          bbox_to_anchor=(1.02, 0.5),
                          fontsize=8,
                          title='Control Spec Violations',
                          title_fontsize=9,
                          framealpha=0.8,
                          edgecolor='gray',
                          borderpad=0.5,
                          handletextpad=0.5,
                          labelspacing=0.5)
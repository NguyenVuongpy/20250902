import numpy as np
from typing import List, Dict, Tuple, Optional
from matplotlib.axes import Axes
import matplotlib.patches as mpatches
from matplotlib.collections import PatchCollection
from controller.setting import Setting
from model.csv_database import CSV_Database
import pandas as pd
import math
from scipy import stats


class ControlSpecAnalyzer:
    """
    A utility class for analyzing and highlighting control spec violations in boxplots
    """
    
    def __init__(self):
        self.PINK_COLOR = "#FFB6C1"    # For CPK < 1.33
        self.ORANGE_COLOR = "#FFCC66"  # For excessive outliers
        self.YELLOW_COLOR = "#FFFF00"  # For median outside sigma line
        self.RED_COLOR = "#FF0000"     # For multiple violations
        self.NORMAL_COLOR = "none"     # For normal boxplots
        self.OUTLIER_MARKER_COLOR = "#FF8C00"  # Red color for outlier markers
        self.has_any_violation = False
        self.violation_plots = set()
        self.OUTLIER_THRESHOLD = 0.02  # 2% threshold for excessive outliers
        
    def calculate_control_limits(self, data_list: List[np.ndarray], plot_item_name: str, ref_file: str = "None",
                                 database: CSV_Database = None, sigma_level: str = "±1.5σ") -> Tuple[float, float, float, float]:
        """
        Calculate control limits from reference data or current data
        Returns: (lower_limit, upper_limit, mean, std)
        """
        data_for_calculation = []
        if ref_file != "None" and database and plot_item_name:
            # Get data for plot_item_name from only the ref_file
            ref_plot_data = database.from_column(
                column=plot_item_name,
                removeNaN=True,
                sort_data_order_by=[ref_file]  # Only get data from ref_file
            )
            if ref_plot_data and ref_file in ref_plot_data and ref_plot_data[ref_file][0] == 'has_data':
                data_for_calculation.extend(ref_plot_data[ref_file][1])
        else:
            # If ref_file is None or invalid, use all available data for the current plot_item
            for data in data_list:
                if len(data) > 0:
                    data_for_calculation.extend(data)
        
        if len(data_for_calculation) == 0:
            return None, None, 0, 0
            
        mean = np.mean(data_for_calculation)
        std = np.std(data_for_calculation)
        
        # Extract sigma value from string
        if sigma_level == "±1.5σ":
            sigma_multiplier = 1.5
        elif sigma_level == "±2σ":
            sigma_multiplier = 2.0
        elif sigma_level == "±2.5σ":
            sigma_multiplier = 2.5
        elif sigma_level == "±3σ":
            sigma_multiplier = 3.0
        elif sigma_level == "±3.5σ":
            sigma_multiplier = 3.5
        elif sigma_level == "±4σ":
            sigma_multiplier = 4.0
        else:
            sigma_multiplier = 1.5  # Default
        
        lower_limit = mean - sigma_multiplier * std
        upper_limit = mean + sigma_multiplier * std
        
        return lower_limit, upper_limit, mean, std
    
    def get_reference_data(self, plot_item_name: str, ref_file: str, database: CSV_Database) -> np.ndarray:
        """
        Get reference data for proportion comparison
        """
        if ref_file != "None" and database and plot_item_name:
            ref_plot_data = database.from_column(
                column=plot_item_name,
                removeNaN=True,
                sort_data_order_by=[ref_file]
            )
            if ref_plot_data and ref_file in ref_plot_data and ref_plot_data[ref_file][0] == 'has_data':
                return np.array(ref_plot_data[ref_file][1])
        return np.array([])
    
    def get_double_outliers(self, data: np.ndarray, 
                          lower_sigma: float, upper_sigma: float,
                          lower_whisker: float, upper_whisker: float) -> np.ndarray:
        """
        Get outliers that are both beyond sigma limits AND beyond whisker limits
        """
        if len(data) == 0:
            return np.array([])
            
        # Points beyond sigma limits
        beyond_sigma = (data < lower_sigma) | (data > upper_sigma)
        
        # Points beyond whisker limits
        beyond_whisker = (data < lower_whisker) | (data > upper_whisker)
        
        # Points that satisfy both conditions
        double_outliers_mask = beyond_sigma & beyond_whisker
        
        return data[double_outliers_mask]
    
    def has_excessive_outliers(self, data: np.ndarray, bp_stats: dict, 
                             lower_sigma: float, upper_sigma: float,
                             q1: float, q3: float) -> Tuple[bool, np.ndarray]:
        """
        Check if a boxplot has excessive outliers and return the outlier points.
        Excessive is defined by:
        1. Percentage of double outliers > OUTLIER_THRESHOLD (2%)
        2. Median of the double outliers is outside Q1 - 4*IQR or Q3 + 4*IQR
        Returns: (has_excessive_outliers, outlier_points)
        """
        if len(data) == 0 or lower_sigma == 0 or upper_sigma == 0:
            return False, np.array([])

        # Get whisker limits from boxplot statistics
        lower_whisker = bp_stats['whislo']
        upper_whisker = bp_stats['whishi']

        # Get double outliers (beyond sigma limits AND beyond whisker limits)
        double_outliers = self.get_double_outliers(
            data, lower_sigma, upper_sigma, lower_whisker, upper_whisker
        )

        # Condition 1: Check if percentage of double outliers exceeds threshold
        outlier_percentage = (len(double_outliers) / len(data)) * 100
        percentage_exceeds_threshold = outlier_percentage > self.OUTLIER_THRESHOLD * 100

        # Condition 2: Check if median of double outliers is outside 4*IQR bounds
        median_outside_4x_iqr_bounds = False
        if len(double_outliers) > 0:
            iqr = q3 - q1
            iqr_lower_bound_4x = q1 - 4 * iqr
            iqr_upper_bound_4x = q3 + 4 * iqr
            
            median_of_double_outliers = np.median(double_outliers)

            if median_of_double_outliers < iqr_lower_bound_4x or \
               median_of_double_outliers > iqr_upper_bound_4x:
                median_outside_4x_iqr_bounds = True
        
        # Combined condition for excessive outliers
        has_excessive = percentage_exceeds_threshold and median_outside_4x_iqr_bounds
        
        return has_excessive, double_outliers
    
    def is_median_outside_sigma(self, median: float, 
                              lower_sigma: float, upper_sigma: float) -> bool:
        """
        Check if the median is outside the sigma limits
        (CHANGED from IQR touching sigma to median outside sigma)
        """
        if lower_sigma == 0 and upper_sigma == 0:
            return False
            
        # Median is outside sigma limits if it's below lower limit or above upper limit
        return median < lower_sigma or median > upper_sigma

    def mark_outlier_regions(self, ax: Axes, outlier_points: np.ndarray, 
                           x_position: float, bp_stats: dict):
        """
        Mark regions with excessive outliers using ellipses that encompass all outlier points
        """
        if len(outlier_points) == 0:
            return
            
        # Get whisker limits for reference
        lower_whisker = bp_stats['whislo']
        upper_whisker = bp_stats['whishi']
        
        # Group outlier points by region (above and below whiskers)
        upper_outliers = outlier_points[outlier_points > upper_whisker]
        lower_outliers = outlier_points[outlier_points < lower_whisker]
        
        # Mark upper outlier region
        if len(upper_outliers) > 0:
            # Calculate ellipse parameters to encompass all upper outliers
            min_upper = np.min(upper_outliers) if len(upper_outliers) > 0 else upper_whisker
            max_upper = np.max(upper_outliers) if len(upper_outliers) > 0 else upper_whisker
            
            upper_center_x = x_position
            upper_center_y = (min_upper + max_upper) / 2
            
            # Calculate ellipse dimensions to cover all points with some padding
            upper_width = 0.3  # Fixed width
            upper_height = (max_upper - min_upper) * 1.2  # Height with 20% padding
            
            # Ensure minimum height
            upper_height = max(upper_height, 0.1)
            
            # Create ellipse for upper outliers with thin line
            ellipse_upper = mpatches.Ellipse(
                (upper_center_x, upper_center_y), 
                width=upper_width,
                height=upper_height,
                fill=False, 
                color=self.OUTLIER_MARKER_COLOR, 
                linewidth=0.5,  # Thin line
                alpha=0.8,
                linestyle='-'
            )
            ax.add_patch(ellipse_upper)
        
        # Mark lower outlier region
        if len(lower_outliers) > 0:
            # Calculate ellipse parameters to encompass all lower outliers
            min_lower = np.min(lower_outliers) if len(lower_outliers) > 0 else lower_whisker
            max_lower = np.max(lower_outliers) if len(lower_outliers) > 0 else lower_whisker
            
            lower_center_x = x_position
            lower_center_y = (min_lower + max_lower) / 2
            
            # Calculate ellipse dimensions to cover all points with some padding
            lower_width = 0.3  # Fixed width
            lower_height = (max_lower - min_lower) * 1.2  # Height with 20% padding
            
            # Ensure minimum height
            lower_height = max(lower_height, 0.1)
            
            # Create ellipse for lower outliers with thin line
            ellipse_lower = mpatches.Ellipse(
                (lower_center_x, lower_center_y), 
                width=lower_width,
                height=lower_height,
                fill=False, 
                color=self.OUTLIER_MARKER_COLOR, 
                linewidth=0.5,  # Thin line
                alpha=0.8,
                linestyle='-'
            )
            ax.add_patch(ellipse_lower)

    def analyze_and_highlight(self, ax: Axes, bp: dict, data_list: List[np.ndarray],
                              plot_item_name: str, plot_index: int = 0, lsl: float = None, usl: float = None,
                              ref_file: str = "None", database: CSV_Database = None,
                              sigma_level: str = "±1.5σ") -> bool:
        """
        Analyze boxplots and highlight control spec violations using statistical tests.
        Returns: True if any violations were found.
        """
        # Only proceed with analysis if any control spec feature is enabled
        # The specific actions (highlighting, drawing lines) will be governed by their respective settings later.
        # The initial check for `Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS` is removed here to allow
        # `is_plot_violation` to be populated for `OPTS_ONLY_SHOW_CONTROL_SPEC_VIOLATIONS` even if highlighting is off.

        has_violation = False
        
        # Calculate control limits (for median check and outlier detection)
        lower_limit, upper_limit, mean, std = self.calculate_control_limits(
            data_list, plot_item_name, ref_file, database, sigma_level
        )
        
        # Draw control spec lines if enabled
        if Setting.OPTS_SHOW_CONTROL_SPEC_LINES and lower_limit is not None and upper_limit is not None:
            # Draw lower control limit line in orange
            ax.axhline(y=lower_limit, linewidth=0.5, color='orange', linestyle='--')
            # Add text for the lower control limit line - ONLY SHOW SIGMA LEVEL
            ax.text(ax.get_xlim()[1], lower_limit, sigma_level, 
                    verticalalignment='center', horizontalalignment='left',
                    color='orange', fontsize=6)
            
            # Draw upper control limit line in orange
            ax.axhline(y=upper_limit, linewidth=0.5, color='orange', linestyle='--')
            # Add text for the upper control limit line - ONLY SHOW SIGMA LEVEL
            ax.text(ax.get_xlim()[1], upper_limit, sigma_level, 
                    verticalalignment='center', horizontalalignment='left',
                    color='orange', fontsize=6)
        
        # Analyze each boxplot
        for i, data in enumerate(data_list):
            if len(data) == 0:
                continue
                
            color = self.NORMAL_COLOR
            violations = []
            outlier_points = np.array([])
            
            # Check CPK violation
            if lsl is not None or usl is not None:
                mean_val = np.mean(data)
                std_val = np.std(data)
                if std_val > 0:
                    if usl is not None and lsl is not None:
                        if usl == 100:
                            cpk = (mean_val - lsl) / (3 * std_val)
                        elif usl == 0:
                            cpk = (mean_val - lsl) / (3 * std_val)
                        elif lsl == 0:
                            cpk = (usl - mean_val) / (3 * std_val)
                        else:
                            cpk = min((usl - mean_val) / (3 * std_val), (mean_val - lsl) / (3 * std_val))
                    elif usl is None and lsl is not None:
                        cpk = (mean_val - lsl) / (3 * std_val)
                    elif usl is not None and lsl is None:
                        cpk = (usl - mean_val) / (3 * std_val)
                    else:
                        cpk = None
                        
                    if cpk is not None and cpk < 1.33:
                        violations.append('cpk')
            
            # Check median outside sigma limits (CHANGED from IQR touching)
            if lower_limit != 0 and upper_limit != 0:
                # Get median from boxplot (the horizontal line inside the box)
                median = bp['medians'][i].get_ydata()[0]  # All y-values are the same for median line
                
                median_outside_sigma = self.is_median_outside_sigma(median, lower_limit, upper_limit)
                
                if median_outside_sigma:
                    violations.append('median_sigma')
            
            # Check outlier violation
            if lower_limit != 0 and upper_limit != 0 and len(data) >= 10:
                # Get boxplot statistics for this specific box
                bp_stats = {
                    'whislo': bp['whiskers'][i*2].get_ydata()[1],  # Lower whisker
                    'whishi': bp['whiskers'][i*2+1].get_ydata()[1]  # Upper whisker
                }
                
                # Calculate Q1 and Q3 for the current box's data
                q1 = np.percentile(data, 25)
                q3 = np.percentile(data, 75)

                has_excessive, outliers = self.has_excessive_outliers(
                    data, bp_stats, lower_limit, upper_limit, q1, q3
                )
                
                if has_excessive:
                    violations.append('outlier')
                    outlier_points = outliers
            
            # Set color based on violations
            if len(violations) >= 2:
                color = self.RED_COLOR
            elif 'cpk' in violations:
                color = self.PINK_COLOR
            elif 'median_sigma' in violations:
                color = self.YELLOW_COLOR
            elif 'outlier' in violations:
                color = self.ORANGE_COLOR
            
            # Apply highlighting to box
            if Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS and color != self.NORMAL_COLOR:
                box = bp['boxes'][i]
                box.set_facecolor(color)
                box.set_alpha(0.7)
                has_violation = True
                self.violation_plots.add(plot_index)
            
            # Mark outlier regions if excessive outliers are detected
            if Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS and 'outlier' in violations and len(outlier_points) > 0:
                # Get x position of the current boxplot
                x_position = bp['boxes'][i].get_path().vertices[0, 0]  # Left edge of the box
                box_width = bp['boxes'][i].get_path().vertices[1, 0] - x_position  # Width of the box
                x_center = x_position + box_width / 2  # Center of the box
                
                # Get boxplot statistics
                bp_stats = {
                    'whislo': bp['whiskers'][i*2].get_ydata()[1],
                    'whishi': bp['whiskers'][i*2+1].get_ydata()[1]
                }
                
                # Mark the outlier regions with thin ellipses
                self.mark_outlier_regions(ax, outlier_points, x_center, bp_stats)
        
        if has_violation:
            self.has_any_violation = True
            
        return has_violation
    
    def is_plot_violation(self, plot_index: int) -> bool:
        """Check if the plot has a violation"""
        return plot_index in self.violation_plots
    
    def reset(self):
        """Reset the analyzer's state"""
        self.has_any_violation = False
        self.violation_plots.clear()
    
    def create_legend_elements(self):
        """Create legend elements for control spec violations"""
        elements = []
        
        if Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS:
            elements.append(mpatches.Patch(facecolor=self.PINK_COLOR, alpha=0.9, label='CPK < 1.33'))
            elements.append(mpatches.Patch(facecolor=self.YELLOW_COLOR, alpha=0.9, label='Med Outside σ Line'))
            elements.append(mpatches.Patch(facecolor=self.ORANGE_COLOR, alpha=0.9, 
                                         label=f'Outliers > {self.OUTLIER_THRESHOLD*100:.0f}%'))
            elements.append(mpatches.Patch(facecolor=self.RED_COLOR, alpha=0.9, label='Multiple Violations'))
        
        return elements
    
    def add_legend(self, ax: Axes):
        """Add a legend to the plot"""
        if self.has_any_violation:
            legend_elements = self.create_legend_elements()
            
            if legend_elements:
                # Calculate legend position
                bbox = ax.get_position()
                # Reduce plot width to make space for the legend
                ax.set_position([bbox.x0, bbox.y0, bbox.width * 0.85, bbox.height])
                
                # Add legend outside the plot
                ax.legend(handles=legend_elements,
                          loc='center left',
                          bbox_to_anchor=(1.02, 0.5),
                          fontsize=8,
                          title='Control Spec Violations',
                          title_fontsize=9,
                          framealpha=0.8,
                          edgecolor='gray',
                          borderpad=0.5,
                          handletextpad=0.5,
                          labelspacing=0.5)